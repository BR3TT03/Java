import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.applet.*;
public class KeyEventDemo extends Applet implements KeyListener {
 int x,y;
	public void init() {
		x=100;
		y=100;
		addKeyListener(this);
		this.setFocusable(true);
	}
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_LEFT) {
			x-=10;
			repaint();
		}
		else if(e.getKeyCode()==KeyEvent.VK_RIGHT) {
			x+=10;
			repaint();
		}
			if(e.getKeyCode()==KeyEvent.VK_DOWN) {
				y+=10;
				repaint();
			}
			else if(e.getKeyCode()==KeyEvent.VK_UP) {
				y-=10;
				repaint();
		}
	}
	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}
	
	public void paint(Graphics g) {
		g.drawLine(x, y, x+100, y);
	}
}
